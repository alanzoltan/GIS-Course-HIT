var json_Doggoexcel_1 =
 {
    "type":"FeatureCollection",
    "name":"Doggoexcel_1",
    "crs":
    {
        "type":"name",
        "properties":
        {
            "name":"urn:ogc:def:crs:OGC:1.3:CRS84"
        }
    },
    "features":
    [{
      "type": "Feature",
      "properties": {
        "Name": "ברקן",
        "Address": "ברקן / הסחלב",
        "Latitude": 32.26706,
        "Longitude": 34.8815,
        "city": "Even Yehuda"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.88150308,
          32.26705883
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "הגפן",
        "Address": "האורן פינת ההדס",
        "Latitude": 31.30896,
        "Longitude": 34.6128,
        "city": "Ofakim"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.612804,
          31.308964
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "פארק הידידות",
        "Address": "האורן 10",
        "Latitude": 31.30744,
        "Longitude": 34.61333,
        "city": "Ofakim"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.6133292,
          31.30744072
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "אלישבע",
        "Address": "מקס נורדאו",
        "Latitude": 31.81001,
        "Longitude": 34.64297,
        "city": "Ashdod"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.64296806,
          31.81000857
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "גולדה",
        "Address": "הרי גולן / הר חרמון",
        "Latitude": 31.78421,
        "Longitude": 34.6317,
        "city": "Ashdod"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.6317043,
          31.78420907
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "הלוחמים",
        "Address": "יוספטל",
        "Latitude": 31.80752,
        "Longitude": 34.65271,
        "city": "Ashdod"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.65271484,
          31.80751714
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "פארק אבנר גרעין",
        "Address": "יהושפט המלך",
        "Latitude": 31.77666,
        "Longitude": 34.64533,
        "city": "Ashdod"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.64532559,
          31.7766622
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "בית סמואל",
        "Address": "רחבת חת\"םסופר",
        "Latitude": 31.2554,
        "Longitude": 34.76857,
        "city": "Be’er-Sheva"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.768571,
          31.255402
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "הפיל",
        "Address": "יהודה הלוי (גן שני אליהו)",
        "Latitude": 31.26751,
        "Longitude": 34.79027,
        "city": "Be’er-Sheva"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.790267,
          31.26751
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "הראשונים",
        "Address": "שדרות יצחק רגר / מונטיפיורי",
        "Latitude": 31.24908,
        "Longitude": 34.79767,
        "city": "Be’er-Sheva"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.797668,
          31.249078
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "טיילת הרכבת",
        "Address": "שדרות צה\"ל/שדרותהעריםהתאומות",
        "Latitude": 31.28768,
        "Longitude": 34.79651,
        "city": "Be'er Sheva"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.79651426,
          31.2876772
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "כיכר קפלן",
        "Address": "כיכר אליעזר קפלן",
        "Latitude": 31.24869,
        "Longitude": 34.7905,
        "city": "Be'er Sheva"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.79050004,
          31.24869077
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "מתחם כיוונים",
        "Address": "קלישר 7",
        "Latitude": 31.25605,
        "Longitude": 34.81186,
        "city": "Be’er-Sheva"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.81186455,
          31.2560454
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "מתנ\"סמרגליות",
        "Address": "ההגנה10",
        "Latitude": 31.23779,
        "Longitude": 34.78541,
        "city": "Be'er Sheva"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.78540597,
          31.23778952
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "סיאטל",
        "Address": "יצחק רגר 132",
        "Latitude": 31.26659,
        "Longitude": 34.79837,
        "city": "Be’er-Sheva"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.79836692,
          31.2665859
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "פארק ה' (פארק יעלים)",
        "Address": "בורלא / ש\"יעגנון",
        "Latitude": 31.25159,
        "Longitude": 34.77688,
        "city": "Be’er-Sheva"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.77687537,
          31.25158737
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "פארק הסופרים",
        "Address": "אינשטיין",
        "Latitude": 31.25591,
        "Longitude": 34.78883,
        "city": "Be’er-Sheva"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.78883198,
          31.25590852
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "פארק הצנחנים",
        "Address": "חנוך גיבתון 2",
        "Latitude": 31.22317,
        "Longitude": 34.77809,
        "city": "Be'er Sheva"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.77808745,
          31.22316924
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "רחבת חיל",
        "Address": "רחבת החיל",
        "Latitude": 31.26137,
        "Longitude": 34.7759,
        "city": "Be’er-Sheva"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.77589503,
          31.2613743
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "שבטה",
        "Address": "שבטה",
        "Latitude": 31.24538,
        "Longitude": 34.77076,
        "city": "Be’er-Sheva"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.770763,
          31.245382
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "שבטה",
        "Address": "רחבת אופירה / משעול מוצא",
        "Latitude": 31.24541,
        "Longitude": 34.77075,
        "city": "Be’er-Sheva"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.77075217,
          31.24541271
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "שומרון",
        "Address": "שומרון 57",
        "Latitude": 31.24762,
        "Longitude": 34.76586,
        "city": "Be’er-Sheva"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.765855,
          31.247622
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "דניאל",
        "Address": "דניאל",
        "Latitude": 32.01807,
        "Longitude": 34.75019,
        "city": "Bat Yam"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.750191,
          32.018069
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "האורגים",
        "Address": "האורגים פינת צילה",
        "Latitude": 32.00855,
        "Longitude": 34.74435,
        "city": "Bat Yam"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.744349,
          32.008553
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "הי\"אמצדכ\"ט בנובמבר",
        "Address": "כ\"טבנובמבר",
        "Latitude": 32.00948,
        "Longitude": 34.75632,
        "city": "Bat Yam"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.756322,
          32.009482
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "הי\"אמצדמוכריהסיגריות",
        "Address": "מוכריהסיגריות6",
        "Latitude": 32.01266,
        "Longitude": 34.75579,
        "city": "Bat Yam"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.755793,
          32.01266
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "הלנה ראפ ונספי הטרור",
        "Address": "מוהליבר 16",
        "Latitude": 32.00699,
        "Longitude": 34.75134,
        "city": "Bat Yam"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.751344,
          32.006987
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "הנ\"ד",
        "Address": "דקר2",
        "Latitude": 32.0189,
        "Longitude": 34.74321,
        "city": "Bat Yam"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.743206,
          32.018905
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "חורשת הנופלים",
        "Address": "הקוממיות",
        "Latitude": 32.00331,
        "Longitude": 34.7503,
        "city": "Bat Yam"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.750303,
          32.003306
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "ליבורנו",
        "Address": "ליבורנו פינת כובשי החרמון",
        "Latitude": 32.01012,
        "Longitude": 34.75967,
        "city": "Bat Yam"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.759665,
          32.010123
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "משה דיין",
        "Address": "סטרומה",
        "Latitude": 32.02085,
        "Longitude": 34.75673,
        "city": "Bat Yam"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.75672937,
          32.02084927
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "שרת",
        "Address": "משה שרת 4",
        "Latitude": 32.01637,
        "Longitude": 34.7521,
        "city": "Bat Yam"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.752103,
          32.016369
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "האילנות",
        "Address": "רחבת אילן",
        "Latitude": 32.07002,
        "Longitude": 34.84662,
        "city": "Givat Shmuel"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.846622,
          32.070023
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "חורשת יובל",
        "Address": "בן גוריון 19",
        "Latitude": 32.07893,
        "Longitude": 34.84753,
        "city": "Givat Shmuel"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.847531,
          32.078928
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "פארק ספורט",
        "Address": "הנשיא 5",
        "Latitude": 32.08266,
        "Longitude": 34.84933,
        "city": "Givat Shmuel"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.849333,
          32.082658
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "פארק רמון",
        "Address": "מנחם בגין 7",
        "Latitude": 32.0738,
        "Longitude": 34.85372,
        "city": "Givat Shmuel"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.853716,
          32.073804
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "אהרון",
        "Address": "שינקין 41",
        "Latitude": 32.07575,
        "Longitude": 34.81338,
        "city": "Givatayim"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.8133767,
          32.07574587
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "אנצו סירני",
        "Address": "אנצו סירני 2",
        "Latitude": 32.07062,
        "Longitude": 34.80237,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.80237095,
          32.07062422
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "הבנים",
        "Address": "הל\"ה20",
        "Latitude": 32.07358,
        "Longitude": 34.80406,
        "city": "Givatayim"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.804064,
          32.073579
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "הזיכרון",
        "Address": "גורדון 36",
        "Latitude": 32.07661,
        "Longitude": 34.81052,
        "city": "Givatayim"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.81052024,
          32.07661069
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "המכתש",
        "Address": "השניים 6",
        "Latitude": 32.07866,
        "Longitude": 34.81074,
        "city": "Givatayim"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.81073524,
          32.07865694
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "העלייה השנייה",
        "Address": "גולומוב 33",
        "Latitude": 32.06969,
        "Longitude": 34.81515,
        "city": "Givatayim"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.815149,
          32.069692
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "ויקטור (צור)",
        "Address": "סמטת צור",
        "Latitude": 32.07744,
        "Longitude": 34.80516,
        "city": "Givatayim"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.80516407,
          32.07744484
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "חיל האוויר",
        "Address": "מצולות ים",
        "Latitude": 32.0636,
        "Longitude": 34.8071,
        "city": "Givatayim"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.80709664,
          32.06360062
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "ילדי הגנים",
        "Address": "משמר הירדן 16-14",
        "Latitude": 32.06157,
        "Longitude": 34.81387,
        "city": "Givatayim"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.81386671,
          32.06157274
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "כורזין",
        "Address": "כורזין / טבנקין",
        "Latitude": 32.05953,
        "Longitude": 34.81668,
        "city": "Givatayim"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.81668393,
          32.05952571
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "מרים",
        "Address": "שינקין 79",
        "Latitude": 32.075,
        "Longitude": 34.81787,
        "city": "Givatayim"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.81786977,
          32.07499901
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "סולד",
        "Address": "אילת 8",
        "Latitude": 32.0688,
        "Longitude": 34.80621,
        "city": "Givatayim"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.80620696,
          32.06880444
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "פארק גבעתיים",
        "Address": "יצחק רבין 53",
        "Latitude": 32.0667,
        "Longitude": 34.81134,
        "city": "Givatayim"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.811341,
          32.066698
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "פטאי",
        "Address": "פטאי 7",
        "Latitude": 32.07729,
        "Longitude": 34.80311,
        "city": "Givatayim"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.803114,
          32.077294
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "קורצ'אק",
        "Address": "שדה בוקר 6",
        "Latitude": 32.06951,
        "Longitude": 34.8098,
        "city": "Givatayim"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.80980374,
          32.06951402
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "הסיגליות",
        "Address": "הסיגליות",
        "Latitude": 32.32118,
        "Longitude": 34.90252,
        "city": "Unknown"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.90252269,
          32.32117916
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "בני ברית",
        "Address": "בני ברית 8",
        "Latitude": 32.15446,
        "Longitude": 34.89032,
        "city": "Hod HaSharon"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.89032216,
          32.1544596
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "גולדה מאיר",
        "Address": "גולדה מאיר / סוקולוב",
        "Latitude": 32.16834,
        "Longitude": 34.90066,
        "city": "Hod HaSharon"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.90065875,
          32.16834231
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "גולן",
        "Address": "הגולן",
        "Latitude": 32.15904,
        "Longitude": 34.92324,
        "city": "Hod HaSharon"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.92324414,
          32.15903695
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "האוטהקר",
        "Address": "ישורון 2",
        "Latitude": 32.15647,
        "Longitude": 34.8926,
        "city": "Hod HaSharon"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.89260334,
          32.1564746
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "האם",
        "Address": "בן גוריון",
        "Latitude": 32.15904,
        "Longitude": 34.88875,
        "city": "Hod HaSharon"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.88874602,
          32.15903669
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "סימטת אבן",
        "Address": "סימטת אבן",
        "Latitude": 32.1522,
        "Longitude": 34.88735,
        "city": "Hod HaSharon"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.88734509,
          32.15220305
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "פארק ארבע העונות",
        "Address": "האגודה",
        "Latitude": 32.14517,
        "Longitude": 34.8827,
        "city": "Hod HaSharon"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.88270108,
          32.14517497
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "פארק ארכיאולוגי",
        "Address": "ששת הימים",
        "Latitude": 32.15708,
        "Longitude": 34.9201,
        "city": "Hod HaSharon"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.92009733,
          32.15707529
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "פארק הכבשים",
        "Address": "הטווס",
        "Latitude": 32.14286,
        "Longitude": 34.89398,
        "city": "Hod HaSharon"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.89397549,
          32.14285983
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "פארק עתידים",
        "Address": "שדרות הנשיאים",
        "Latitude": 32.16329,
        "Longitude": 34.90845,
        "city": "Hod HaSharon"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.90845,
          32.16329279
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "א.ד. גורדון",
        "Address": "א.ד. גורדון 35",
        "Latitude": 32.15611,
        "Longitude": 34.84415,
        "city": "Herzliya"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.844151,
          32.156114
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "גינה ע\"שגילישקד",
        "Address": "אלקלעיפינתדבורהעומר",
        "Latitude": 32.17432,
        "Longitude": 34.83507,
        "city": "Herzliya"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.83507142,
          32.17432451
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "גליל ים",
        "Address": "הקרן",
        "Latitude": 32.15938,
        "Longitude": 34.82007,
        "city": "Herzliya"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.82007203,
          32.15937942
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "גן תמיר",
        "Address": "וינגייט 2",
        "Latitude": 32.18275,
        "Longitude": 34.80747,
        "city": "Herzliya"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.807468,
          32.18275
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "דפנה אילת (גן רש\"ל)",
        "Address": "האילנות",
        "Latitude": 32.17798,
        "Longitude": 34.84856,
        "city": "Herzliya"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.84855578,
          32.17797508
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "הבנים",
        "Address": "הבנים 48",
        "Latitude": 32.16316,
        "Longitude": 34.85078,
        "city": "Herzliya"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.850782,
          32.163159
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "המקובלים",
        "Address": "חורשת המקובלים",
        "Latitude": 32.15376,
        "Longitude": 34.8389,
        "city": "Herzliya"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.838901,
          32.153764
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "הרצליה",
        "Address": "יוסף נבו",
        "Latitude": 32.16798,
        "Longitude": 34.82404,
        "city": "Herzliya"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.824042,
          32.167977
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "כצנלסון",
        "Address": "בורוכוב 49",
        "Latitude": 32.17251,
        "Longitude": 34.85626,
        "city": "Herzliya"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.856256,
          32.17251
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "פינסקר",
        "Address": "פינסקר פינת עזרא הסופר",
        "Latitude": 32.16811,
        "Longitude": 34.83196,
        "city": "Herzliya"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.831963,
          32.168112
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "אקופארק",
        "Address": "שניר",
        "Latitude": 32.42984,
        "Longitude": 34.93345,
        "city": "Hadera"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.93344979,
          32.42984482
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "שכונת ניסן",
        "Address": "פיינברג / חנה סנש",
        "Latitude": 32.42768,
        "Longitude": 34.92203,
        "city": "Hadera"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.92202901,
          32.4276832
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "גן סיפור הזיקית",
        "Address": "השומרון",
        "Latitude": 32.02769,
        "Longitude": 34.77584,
        "city": "Holon"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.7758377,
          32.02768591
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "הבנים",
        "Address": "בן גוריון / שייקה דן",
        "Latitude": 31.99629,
        "Longitude": 34.76765,
        "city": "Holon"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.767651,
          31.996286
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "הגאונים",
        "Address": "הגאונים",
        "Latitude": 32.00293,
        "Longitude": 34.76104,
        "city": "Holon"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.76103602,
          32.00292971
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "חורשת היובל",
        "Address": "משה דיין",
        "Latitude": 32.00085,
        "Longitude": 34.76471,
        "city": "Holon"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.764711,
          32.000848
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "חורשת נווה ארזים",
        "Address": "פרופסור משה שור",
        "Latitude": 32.01888,
        "Longitude": 34.79523,
        "city": "Holon"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.795232,
          32.018882
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "לוי אשכול",
        "Address": "לוי אשכול",
        "Latitude": 32.03108,
        "Longitude": 34.77416,
        "city": "Holon"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.77416201,
          32.03108489
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "מטולה",
        "Address": "מטולה",
        "Latitude": 32.00307,
        "Longitude": 34.78702,
        "city": "Holon"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.78701678,
          32.00307306
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "סיפור העץ הנדיב",
        "Address": "אליעזר הופיין 46",
        "Latitude": 32.01344,
        "Longitude": 34.77051,
        "city": "Holon"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.77051167,
          32.01343585
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "סיפור כספיון הדג הקטן",
        "Address": "יוחאי בן נון 7",
        "Latitude": 32.01278,
        "Longitude": 34.7839,
        "city": "Holon"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.78390371,
          32.01277931
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "פארק הפילבוקס",
        "Address": "המצודה 1",
        "Latitude": 32.03451,
        "Longitude": 34.76787,
        "city": "Holon"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.76786774,
          32.03450913
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "קרית עבודה",
        "Address": "דוד רמז",
        "Latitude": 32.00964,
        "Longitude": 34.767,
        "city": "Holon"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.767002,
          32.009642
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "אוקלהומה סיטי",
        "Address": "רמז 17",
        "Latitude": 32.03792,
        "Longitude": 34.88582,
        "city": "Yehud Monosson"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.885815,
          32.037915
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "אלטלף",
        "Address": "אלטלף 25",
        "Latitude": 32.03105,
        "Longitude": 34.89896,
        "city": "Yehud Monosson"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.89895507,
          32.03104956
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "מונוסון",
        "Address": "פנינים 6",
        "Latitude": 32.03029,
        "Longitude": 34.87327,
        "city": "Yehud Monosson"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.873274,
          32.030292
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "סביונים",
        "Address": "משה דיין 18",
        "Latitude": 32.03217,
        "Longitude": 34.87677,
        "city": "Yehud Monosson"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.876766,
          32.032169
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "ארנונה",
        "Address": "קורא הדורות 33",
        "Latitude": 31.7485,
        "Longitude": 35.2221,
        "city": "Jerusalem"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          35.222098,
          31.748495
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "גילה",
        "Address": "המרגלית / הסנונית",
        "Latitude": 31.73013,
        "Longitude": 35.18503,
        "city": "Jerusalem"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          35.185033,
          31.730129
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "הגבעה הצרפתית",
        "Address": "בר כוכבא / החי\"ל",
        "Latitude": 31.80573,
        "Longitude": 35.23995,
        "city": "Jerusalem"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          35.239948,
          31.805732
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "העצמאות",
        "Address": "הרב אבידע 7",
        "Latitude": 31.77753,
        "Longitude": 35.21729,
        "city": "Jerusalem"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          35.217287,
          31.777525
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "השבשבות",
        "Address": "יהודה קרני",
        "Latitude": 31.81034,
        "Longitude": 35.19721,
        "city": "Jerusalem"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          35.19721,
          31.810344
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "סאקר",
        "Address": "שדרות בן צבי 1",
        "Latitude": 31.78062,
        "Longitude": 35.20766,
        "city": "Jerusalem"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          35.207657,
          31.780618
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "סוקולוב",
        "Address": "סוקולוב 12",
        "Latitude": 31.77224,
        "Longitude": 35.21898,
        "city": "Jerusalem"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          35.218984,
          31.772236
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "סן סימון",
        "Address": "מעלה זאב 9",
        "Latitude": 31.76161,
        "Longitude": 35.20634,
        "city": "Jerusalem"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          35.206336,
          31.761609
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "פארק אמת המים",
        "Address": "אלקחי",
        "Latitude": 31.75214,
        "Longitude": 35.23426,
        "city": "Jerusalem"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          35.234261,
          31.752138
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "פארק גוננים",
        "Address": "נהוראי",
        "Latitude": 31.75521,
        "Longitude": 35.20884,
        "city": "Jerusalem"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          35.208839,
          31.755208
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "פארק דניה (פישמן)",
        "Address": "גולומב",
        "Latitude": 31.76192,
        "Longitude": 35.17728,
        "city": "Jerusalem"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          35.17728,
          31.761917
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "פארק מקסיקו",
        "Address": "מקסיקו",
        "Latitude": 31.75606,
        "Longitude": 35.16784,
        "city": "Jerusalem"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          35.167844,
          31.756062
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "פארק שמואל תמיר",
        "Address": "שמואל תמיר כצנלסון",
        "Latitude": 31.82042,
        "Longitude": 35.23619,
        "city": "Jerusalem"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          35.236191,
          31.82042
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "פסגת זאב מזרח",
        "Address": "חנה בבלי",
        "Latitude": 31.8222,
        "Longitude": 35.25602,
        "city": "Jerusalem"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          35.256017,
          31.822204
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "רמות",
        "Address": "זרחי",
        "Latitude": 31.8139,
        "Longitude": 35.19194,
        "city": "Jerusalem"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          35.191938,
          31.813897
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "אברהם קרן",
        "Address": "אברהם קרן 19",
        "Latitude": 32.17107,
        "Longitude": 34.91174,
        "city": "Kfar Saba"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.911743,
          32.171072
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "אנגל",
        "Address": "אנגל 39",
        "Latitude": 32.19717,
        "Longitude": 34.89657,
        "city": "Kfar Saba"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.896567,
          32.197172
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "דוד זהבי",
        "Address": "דוד זהבי",
        "Latitude": 32.18531,
        "Longitude": 34.89289,
        "city": "Kfar Saba"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.89289,
          32.185306
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "הדקל",
        "Address": "הגליל 12",
        "Latitude": 32.17463,
        "Longitude": 34.91731,
        "city": "Kfar Saba"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.917314,
          32.174634
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "המפלס",
        "Address": "המפלס 12",
        "Latitude": 32.17764,
        "Longitude": 34.91668,
        "city": "Kfar Saba"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.916681,
          32.177639
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "התחייה",
        "Address": "התחייה 17",
        "Latitude": 32.1739,
        "Longitude": 34.90405,
        "city": "Kfar Saba"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.904054,
          32.173895
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "חורון",
        "Address": "חורון פינת המוביל",
        "Latitude": 32.17923,
        "Longitude": 34.93127,
        "city": "Kfar Saba"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.931266,
          32.179227
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "כלנית",
        "Address": "כלנית 22",
        "Latitude": 32.17388,
        "Longitude": 34.8939,
        "city": "Kfar Saba"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.893896,
          32.173879
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "עמק חרוד",
        "Address": "עמק חרוד 6",
        "Latitude": 32.17895,
        "Longitude": 34.93587,
        "city": "Kfar Saba"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.935865,
          32.178951
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "פארק כפר סבא - שער האצטדיון",
        "Address": "ג'ו עמר",
        "Latitude": 32.18216,
        "Longitude": 34.92586,
        "city": "Kfar Saba"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.925857,
          32.182158
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "פארק כפר סבא - שער וייצמן",
        "Address": "וייצמן",
        "Latitude": 32.17213,
        "Longitude": 34.92271,
        "city": "Kfar Saba"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.922705,
          32.172132
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "קדושי קהיר",
        "Address": "משה סנה 17",
        "Latitude": 32.18507,
        "Longitude": 34.8966,
        "city": "Kfar Saba"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.896598,
          32.185068
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "שיבת ציון",
        "Address": "שיבת ציון 13",
        "Latitude": 32.18003,
        "Longitude": 34.89406,
        "city": "Kfar Saba"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.89406,
          32.180032
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "הורדים",
        "Address": "מנחם בגין / החשמונאים",
        "Latitude": 31.87946,
        "Longitude": 34.99795,
        "city": "Modiin-Maccabim-Reut"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.99794529,
          31.87946039
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "התפוח",
        "Address": "יצחק רבין / החשמונאים",
        "Latitude": 31.89336,
        "Longitude": 35.00113,
        "city": "Modiin-Maccabim-Reut"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          35.00113427,
          31.89335944
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "חורשת האומות",
        "Address": "עמק איילון 10",
        "Latitude": 31.9057,
        "Longitude": 35.01835,
        "city": "Modiin-Maccabim-Reut"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          35.01834984,
          31.90570114
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "יער יתיר",
        "Address": "יער יתיר 19",
        "Latitude": 31.89683,
        "Longitude": 34.98698,
        "city": "Modiin-Maccabim-Reut"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.98697927,
          31.89683062
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "מוטה גור",
        "Address": "מוטה גור 12",
        "Latitude": 31.91051,
        "Longitude": 34.99639,
        "city": "Modiin-Maccabim-Reut"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.99638805,
          31.91050987
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "מכבים",
        "Address": "שדרת המכבים",
        "Latitude": 31.88876,
        "Longitude": 35.0332,
        "city": "Modiin-Maccabim-Reut"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          35.03319663,
          31.88875543
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "מנחם בגין",
        "Address": "מנחם בגין 26",
        "Latitude": 31.88157,
        "Longitude": 35.01274,
        "city": "Modiin-Maccabim-Reut"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          35.01273675,
          31.88156577
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "ניסן",
        "Address": "ניסן 115",
        "Latitude": 31.91915,
        "Longitude": 35.00807,
        "city": "Modiin-Maccabim-Reut"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          35.00806872,
          31.91914869
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "עמק האלה",
        "Address": "עמק האלה 26",
        "Latitude": 31.91259,
        "Longitude": 35.01153,
        "city": "Modiin-Maccabim-Reut"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          35.01152607,
          31.91258753
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "עמק החולה",
        "Address": "עמק החולה 3",
        "Latitude": 31.89332,
        "Longitude": 35.02421,
        "city": "Modiin-Maccabim-Reut"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          35.02421066,
          31.89332194
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "עמק זבולון",
        "Address": "עמק זבולון 4",
        "Latitude": 31.90282,
        "Longitude": 35.0011,
        "city": "Modiin-Maccabim-Reut"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          35.00109571,
          31.9028247
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "פארק ענבה",
        "Address": "עמק זבולון 3",
        "Latitude": 31.90003,
        "Longitude": 35.00217,
        "city": "Modiin-Maccabim-Reut"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          35.00216837,
          31.90002974
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "רעות",
        "Address": "משעול עוז צמח",
        "Latitude": 31.88956,
        "Longitude": 35.01274,
        "city": "Modiin-Maccabim-Reut"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          35.01274293,
          31.889556
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "פארק הכלבים",
        "Address": "השקד 43",
        "Latitude": 32.98879,
        "Longitude": 35.08314,
        "city": "Nahariya"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          35.083137,
          32.988789
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "המלאכה",
        "Address": "המלאכה",
        "Latitude": 32.3168,
        "Longitude": 34.8974,
        "city": "Nordia"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.89740255,
          32.31680332
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "ברקת",
        "Address": "ברקת",
        "Latitude": 31.92118,
        "Longitude": 34.80977,
        "city": "Ness Ziona"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.80976543,
          31.92117888
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "גן נווה",
        "Address": "יציאת אירופה",
        "Latitude": 31.92794,
        "Longitude": 34.8077,
        "city": "Ness Ziona"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.80770074,
          31.92793817
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "גרנד וייל",
        "Address": "הטייסים",
        "Latitude": 31.93254,
        "Longitude": 34.79525,
        "city": "Ness Ziona"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.79524916,
          31.93254223
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "הגיא",
        "Address": "הגיא",
        "Latitude": 31.92583,
        "Longitude": 34.81306,
        "city": "Ness Ziona"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.81305854,
          31.92582937
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "וואלי",
        "Address": "עונות השנה",
        "Latitude": 31.91187,
        "Longitude": 34.78944,
        "city": "Ness Ziona"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.78943861,
          31.91186586
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "טוסקנה",
        "Address": "הדס",
        "Latitude": 31.94033,
        "Longitude": 34.79404,
        "city": "Ness Ziona"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.79404482,
          31.94032954
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "כ\"טבנובמבר",
        "Address": "המאהואחד/גבעותהכורכר",
        "Latitude": 31.93729,
        "Longitude": 34.78825,
        "city": "Ness Ziona"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.78825227,
          31.93728512
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "מליבו",
        "Address": "לנדאו / מנחם בגין",
        "Latitude": 31.92404,
        "Longitude": 34.78329,
        "city": "Ness Ziona"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.78328691,
          31.92403565
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "ספורטק",
        "Address": "וייצמן",
        "Latitude": 31.93384,
        "Longitude": 34.80123,
        "city": "Ness Ziona"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.80122843,
          31.93384396
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "עמק השושנים",
        "Address": "עמק השושנים / המעפילים",
        "Latitude": 31.92825,
        "Longitude": 34.78922,
        "city": "Ness Ziona"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.7892157,
          31.92824744
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "בית לנדאו",
        "Address": "אורח חיים 4",
        "Latitude": 32.76396,
        "Longitude": 35.04837,
        "city": "Nesher"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          35.04837,
          32.763959
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "התשבי",
        "Address": "התשבי",
        "Latitude": 32.76443,
        "Longitude": 35.05141,
        "city": "Nesher"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          35.051412,
          32.764426
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "רוסלן",
        "Address": "האורן, ששת הימים והחצב",
        "Latitude": 32.77046,
        "Longitude": 35.04144,
        "city": "Nesher"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          35.041435,
          32.770456
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "אגם החורף",
        "Address": "יצחק מודעי 7",
        "Latitude": 32.29311,
        "Longitude": 34.84435,
        "city": "Netanya"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.844352,
          32.293107
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "אירוסים צפוני",
        "Address": "אירוס הארגמן 36",
        "Latitude": 32.28655,
        "Longitude": 34.84809,
        "city": "Netanya"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.84808746,
          32.28654864
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "אלברט אינשטיין",
        "Address": "איסר הראל 2",
        "Latitude": 32.33843,
        "Longitude": 34.87166,
        "city": "Netanya"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.87166222,
          32.33843085
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "אמנון ותמר",
        "Address": "סבידור 84",
        "Latitude": 32.2733,
        "Longitude": 34.8495,
        "city": "Netanya"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.84949796,
          32.2733009
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "גורדון",
        "Address": "גורדון 51",
        "Latitude": 32.33678,
        "Longitude": 34.85805,
        "city": "Netanya"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.85804749,
          32.33677516
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "הברוש פינת תאשור",
        "Address": "ברוש 7",
        "Latitude": 32.29907,
        "Longitude": 34.87559,
        "city": "Netanya"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.87559037,
          32.29907144
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "הגיבורים",
        "Address": "עציון 12",
        "Latitude": 32.33722,
        "Longitude": 34.86275,
        "city": "Netanya"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.86275423,
          32.33722168
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "הדקל",
        "Address": "הדקל",
        "Latitude": 32.30168,
        "Longitude": 34.87517,
        "city": "Netanya"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.875174,
          32.301676
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "הקליר",
        "Address": "הקליר 3",
        "Latitude": 32.31454,
        "Longitude": 34.86056,
        "city": "Netanya"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.86056215,
          32.31453916
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "חפציבה",
        "Address": "יצחק בן חנן",
        "Latitude": 32.3117,
        "Longitude": 34.88765,
        "city": "Netanya"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.88765267,
          32.3117011
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "כיכר אמנון ותמר",
        "Address": "אמנון ותמר 23",
        "Latitude": 32.27658,
        "Longitude": 34.84925,
        "city": "Netanya"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.84924633,
          32.27658222
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "נאות גולדה",
        "Address": "גולדה מאיר 136",
        "Latitude": 32.27691,
        "Longitude": 34.85346,
        "city": "Netanya"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.85346373,
          32.27691304
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "נאות שקד",
        "Address": "מוצקין 2",
        "Latitude": 32.29536,
        "Longitude": 34.84764,
        "city": "Netanya"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.84764256,
          32.29535849
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "נת 600",
        "Address": "בני בנימין 40",
        "Latitude": 32.29646,
        "Longitude": 34.84229,
        "city": "Netanya"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.84229039,
          32.29645943
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "סירקין",
        "Address": "סירקין 10",
        "Latitude": 32.32057,
        "Longitude": 34.88619,
        "city": "Netanya"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.88618907,
          32.32056563
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "עין התכלת",
        "Address": "הנרקיס / השושנה",
        "Latitude": 32.35014,
        "Longitude": 34.85915,
        "city": "Netanya"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.85914982,
          32.35013724
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "עיר ימים",
        "Address": "יוסי בנאי",
        "Latitude": 32.27741,
        "Longitude": 34.84359,
        "city": "Netanya"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.843592,
          32.277405
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "ציר כחול",
        "Address": "אהוד מנור 12",
        "Latitude": 32.27663,
        "Longitude": 34.83909,
        "city": "Netanya"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.83909356,
          32.27663026
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "רותם",
        "Address": "חרצית",
        "Latitude": 32.28615,
        "Longitude": 34.84875,
        "city": "Netanya"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.848745,
          32.286154
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "רותם מערבי צפוני",
        "Address": "רותם 11",
        "Latitude": 32.2857,
        "Longitude": 34.84929,
        "city": "Netanya"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.84928545,
          32.28569842
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "שבטי ישראל",
        "Address": "שבטי ישראל 6",
        "Latitude": 32.30159,
        "Longitude": 34.87091,
        "city": "Netanya"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.87091,
          32.30159
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "שבטי ישראל פינת ליבר",
        "Address": "זאב ליבר 10",
        "Latitude": 32.30014,
        "Longitude": 34.87242,
        "city": "Netanya"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.87241896,
          32.30014199
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "שלולית החורף",
        "Address": "בן גוריון 143",
        "Latitude": 32.293,
        "Longitude": 34.84432,
        "city": "Netanya"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.84431824,
          32.29300162
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "שלונסקי 22",
        "Address": "שלונסקי 22",
        "Latitude": 32.28614,
        "Longitude": 34.85289,
        "city": "Netanya"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.85289246,
          32.28614176
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "שרה",
        "Address": "ירושלים 11",
        "Latitude": 32.32485,
        "Longitude": 34.85283,
        "city": "Netanya"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.85283499,
          32.32485051
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "תומאס אדיסון",
        "Address": "תומאס אדיסון",
        "Latitude": 32.29292,
        "Longitude": 34.85537,
        "city": "Netanya"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.85536673,
          32.29292004
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "בן גוריון",
        "Address": "יוסף גרשון - שכונת בן גוריון",
        "Latitude": 32.92215,
        "Longitude": 35.09593,
        "city": "Acre"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          35.095927,
          32.922145
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "אח\"יאילת",
        "Address": "קפלן10",
        "Latitude": 32.63129,
        "Longitude": 35.32536,
        "city": "Afula"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          35.32536,
          32.631287
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "פארק הרכבת",
        "Address": "אורנים 19",
        "Latitude": 32.61295,
        "Longitude": 35.28502,
        "city": "Afula"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          35.285021,
          32.612948
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "פארק עירוני",
        "Address": "ספיר",
        "Latitude": 32.6169,
        "Longitude": 35.30841,
        "city": "Afula"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          35.308415,
          32.616897
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "בן צבי",
        "Address": "יצחק בן צבי",
        "Latitude": 32.07269,
        "Longitude": 34.88665,
        "city": "Petah Tikva"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.886653,
          32.072692
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "הדר גנים",
        "Address": "השופר",
        "Latitude": 32.07986,
        "Longitude": 34.9056,
        "city": "Petah Tikva"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.905604,
          32.079864
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "הדר המושבות",
        "Address": "גיסין - חורשת האקליפטוסים",
        "Latitude": 32.09933,
        "Longitude": 34.87183,
        "city": "Petah Tikva"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.87183,
          32.099332
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "הנשיא",
        "Address": "חיים כהן / בן יהודה",
        "Latitude": 32.08079,
        "Longitude": 34.88264,
        "city": "Petah Tikva"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.882641,
          32.080786
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "יונה בוגלה",
        "Address": "אסף שמחוני",
        "Latitude": 32.07403,
        "Longitude": 34.89262,
        "city": "Petah Tikva"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.892624,
          32.074026
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "כפר גנים",
        "Address": "משה נקאש",
        "Latitude": 32.07073,
        "Longitude": 34.861,
        "city": "Petah Tikva"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.860998,
          32.07073
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "נוה עוז",
        "Address": "אלכסנדר זייד",
        "Latitude": 32.07639,
        "Longitude": 34.86394,
        "city": "Petah Tikva"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.863944,
          32.076386
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "נחום הלר",
        "Address": "אחד העם",
        "Latitude": 32.0847,
        "Longitude": 34.8934,
        "city": "Petah Tikva"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.893401,
          32.084695
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "פארק יד לבנים",
        "Address": "משה שרת",
        "Latitude": 32.08771,
        "Longitude": 34.87402,
        "city": "Petah Tikva"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.874023,
          32.087707
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "קק\"ל",
        "Address": "קק\"ל 37",
        "Latitude": 32.08032,
        "Longitude": 34.88757,
        "city": "Petah Tikva"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.887573,
          32.080322
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "קרית אלון",
        "Address": "דוד רמז - חורשת ששת הימים",
        "Latitude": 32.08874,
        "Longitude": 34.90503,
        "city": "Petah Tikva"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.905034,
          32.088741
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "אילן לובודה",
        "Address": "רמה",
        "Latitude": 32.06228,
        "Longitude": 34.86083,
        "city": "Kiryat Ono"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.86082941,
          32.06228178
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "חורשת הפסגה",
        "Address": "יצחק רבין",
        "Latitude": 32.06549,
        "Longitude": 34.86438,
        "city": "Kiryat Ono"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.86437674,
          32.06549186
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "חורשת קובו",
        "Address": "המעגל 16",
        "Latitude": 32.04843,
        "Longitude": 34.86716,
        "city": "Kiryat Ono"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.86716226,
          32.04842799
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "פארק ורשה",
        "Address": "אמיל זולא",
        "Latitude": 32.06606,
        "Longitude": 34.85736,
        "city": "Kiryat Ono"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.85736011,
          32.0660643
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "פארק צה\"ל",
        "Address": "צה\"ל",
        "Latitude": 32.05199,
        "Longitude": 34.86014,
        "city": "Kiryat Ono"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.86013551,
          32.05199093
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "פארק רייספלד",
        "Address": "המייסדים",
        "Latitude": 32.05581,
        "Longitude": 34.85605,
        "city": "Kiryat Ono"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.85604581,
          32.05581166
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "פארק שטרן",
        "Address": "יאיר שטרן",
        "Latitude": 32.05215,
        "Longitude": 34.86608,
        "city": "Kiryat Ono"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.86607736,
          32.05215226
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "קק\"ל",
        "Address": "שדרותקק\"ל",
        "Latitude": 32.06468,
        "Longitude": 34.84957,
        "city": "Kiryat Ono"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.84957172,
          32.06468346
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "שער הדרום",
        "Address": "אדוריים / המעפיל",
        "Latitude": 31.60271,
        "Longitude": 34.76133,
        "city": "Kiryat Gat"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.761326,
          31.602708
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "אריה",
        "Address": "ז'בוטינסקי",
        "Latitude": 32.83862,
        "Longitude": 35.06681,
        "city": "Kiryat Yam"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          35.06681353,
          32.83861899
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "חוף הים",
        "Address": "שדרות פנחס ספיר",
        "Latitude": 32.84514,
        "Longitude": 35.0598,
        "city": "Kiryat Yam"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          35.05980199,
          32.84513783
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "סביוני ים",
        "Address": "שדרות ארזים",
        "Latitude": 32.85821,
        "Longitude": 35.08155,
        "city": "Kiryat Yam"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          35.08154877,
          32.85821191
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "פארק תבור",
        "Address": "תבור",
        "Latitude": 32.85475,
        "Longitude": 35.08174,
        "city": "Kiryat Yam"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          35.08174023,
          32.85475374
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "פסגות ים",
        "Address": "ציפורן",
        "Latitude": 32.84706,
        "Longitude": 35.07746,
        "city": "Kiryat Yam"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          35.07746049,
          32.8470559
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "אחוזת ראשונים",
        "Address": "הנחשול 28-26",
        "Latitude": 31.98681,
        "Longitude": 34.78411,
        "city": "Rishon LeZion"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.784106,
          31.986809
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "אלתרמן",
        "Address": "אלתרמן 1",
        "Latitude": 31.97474,
        "Longitude": 34.76933,
        "city": "Rishon LeZion"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.76932745,
          31.97473618
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "ארזים",
        "Address": "סעדיה ויוסף בשארי 11",
        "Latitude": 31.98059,
        "Longitude": 34.80382,
        "city": "Rishon LeZion"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.80381647,
          31.98058604
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "דוד הלוי",
        "Address": "חיים דוד הלוי 2",
        "Latitude": 31.94605,
        "Longitude": 34.81683,
        "city": "Rishon LeZion"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.816827,
          31.946049
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "הזיכרון",
        "Address": "חסידי אומות העולם 1",
        "Latitude": 31.97673,
        "Longitude": 34.78308,
        "city": "Rishon LeZion"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.78308316,
          31.97673356
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "החלוצים",
        "Address": "החלוצים 90",
        "Latitude": 31.98052,
        "Longitude": 34.7587,
        "city": "Rishon LeZion"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.75870008,
          31.98051897
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "הכימיה",
        "Address": "מעגל השלום 15",
        "Latitude": 31.96908,
        "Longitude": 34.76511,
        "city": "Rishon LeZion"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.76510737,
          31.96908045
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "המוסיקה",
        "Address": "דרובין 40",
        "Latitude": 31.95572,
        "Longitude": 34.79875,
        "city": "Rishon LeZion"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.79875137,
          31.95572231
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "המושבה",
        "Address": "הכרמל 20",
        "Latitude": 31.96211,
        "Longitude": 34.80347,
        "city": "Rishon LeZion"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.80347118,
          31.96210685
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "חוף הים",
        "Address": "טיילת צפונית",
        "Latitude": 32.00105,
        "Longitude": 34.73338,
        "city": "Rishon LeZion"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.733379,
          32.001047
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "חיל האוויר",
        "Address": "חיל האוויר",
        "Latitude": 31.99787,
        "Longitude": 34.74227,
        "city": "Rishon LeZion"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.74227332,
          31.99786618
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "יונתן (טיילת שפד\"ן)",
        "Address": "רחבעםזאבי",
        "Latitude": 31.9927,
        "Longitude": 34.74672,
        "city": "Rishon LeZion"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.74672205,
          31.9927048
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "מונדריאן",
        "Address": "ה' באייר 33",
        "Latitude": 31.98208,
        "Longitude": 34.77979,
        "city": "Rishon LeZion"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.7797909,
          31.98207608
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "פארק אבי האסירים",
        "Address": "אבי האסירים 6",
        "Latitude": 31.95424,
        "Longitude": 34.80319,
        "city": "Rishon LeZion"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.803191,
          31.954244
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "פארק ההסתדרות",
        "Address": "ההסתדרות / גשר המוזיאון",
        "Latitude": 31.96671,
        "Longitude": 34.78379,
        "city": "Rishon LeZion"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.78379218,
          31.96671089
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "פארק היקפי 6",
        "Address": "מדרום למלך הגשם 8",
        "Latitude": 31.9677,
        "Longitude": 34.76134,
        "city": "Rishon LeZion"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.76133845,
          31.96769754
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "פארק המעיין",
        "Address": "בן גוריון 37",
        "Latitude": 31.96957,
        "Longitude": 34.79003,
        "city": "Rishon LeZion"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.79002891,
          31.96956767
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "פארק המצילתיים",
        "Address": "המצילתיים 1",
        "Latitude": 31.9645,
        "Longitude": 34.77512,
        "city": "Rishon LeZion"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.77511986,
          31.96449832
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "פארק חולות צפון 1",
        "Address": "מאחורי כפר חיטים 7",
        "Latitude": 31.96243,
        "Longitude": 34.78184,
        "city": "Rishon LeZion"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.78184436,
          31.9624325
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "פארק יונה בוגלה",
        "Address": "יונה בוגלה 19",
        "Latitude": 31.94635,
        "Longitude": 34.8203,
        "city": "Rishon LeZion"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.82030077,
          31.94635397
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "פארק יוסף בורג",
        "Address": "יוסף בורג 7",
        "Latitude": 31.96888,
        "Longitude": 34.81997,
        "city": "Rishon LeZion"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.81996787,
          31.96888403
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "פארק נאות השקמה",
        "Address": "חיים בר-לב 1",
        "Latitude": 31.97782,
        "Longitude": 34.76419,
        "city": "Rishon LeZion"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.76418969,
          31.97782019
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "פארק תורה ועבודה",
        "Address": "תורה ועבודה 1",
        "Latitude": 31.98885,
        "Longitude": 34.78955,
        "city": "Rishon LeZion"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.7895481,
          31.98884996
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "קרית ראשון",
        "Address": "ההרדוף",
        "Latitude": 31.97242,
        "Longitude": 34.7853,
        "city": "Rishon LeZion"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.785304,
          31.972424
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "רביבים",
        "Address": "גבעתי 39",
        "Latitude": 31.9636,
        "Longitude": 34.81741,
        "city": "Rishon LeZion"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.8174133,
          31.9635986
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "רפפורט",
        "Address": "רפפורט 7",
        "Latitude": 31.96696,
        "Longitude": 34.82411,
        "city": "Rishon LeZion"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.82411435,
          31.96696031
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "שער המלך דרום",
        "Address": "שער המלך 4",
        "Latitude": 31.99383,
        "Longitude": 34.74579,
        "city": "Rishon LeZion"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.74578981,
          31.99382766
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "אחוזות הנשיא",
        "Address": "כרמל",
        "Latitude": 31.90742,
        "Longitude": 34.82166,
        "city": "Rehovot"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.821662,
          31.907422
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "גבעת האהבה",
        "Address": "פנחס בן דוד",
        "Latitude": 31.88018,
        "Longitude": 34.8099,
        "city": "Rehovot"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.809901,
          31.880179
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "הבנים - נווה יהודה",
        "Address": "אהרונוביץ 15",
        "Latitude": 31.90131,
        "Longitude": 34.80145,
        "city": "Rehovot"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.801454,
          31.901307
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "היובל",
        "Address": "דרך ירושלים",
        "Latitude": 31.88851,
        "Longitude": 34.82546,
        "city": "Rehovot"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.825458,
          31.88851
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "חורשת ותיקים",
        "Address": "קנדלר פינת נח קרומר",
        "Latitude": 31.89268,
        "Longitude": 34.80087,
        "city": "Rehovot"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.800865,
          31.892678
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "פארק רחובות המדע",
        "Address": "דניאל כהנמן",
        "Latitude": 31.90486,
        "Longitude": 34.82231,
        "city": "Rehovot"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.822312,
          31.904857
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "רחובות ההולנדית",
        "Address": "הר הצופים",
        "Latitude": 31.89664,
        "Longitude": 34.78155,
        "city": "Rehovot"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.781545,
          31.896639
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "בריל",
        "Address": "אבא אחמיאיר",
        "Latitude": 31.93773,
        "Longitude": 34.87431,
        "city": "Lod"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.874306,
          31.937734
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "ההגנה",
        "Address": "ההגנה",
        "Latitude": 31.9324,
        "Longitude": 34.87019,
        "city": "Ramla"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.870188,
          31.932395
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "מוצקין",
        "Address": "מוצקין",
        "Latitude": 31.93534,
        "Longitude": 34.86901,
        "city": "Ramla"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.869014,
          31.935337
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "פארק גולדה",
        "Address": "קרן היסוד",
        "Latitude": 31.92778,
        "Longitude": 34.85498,
        "city": "Ramla"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.854975,
          31.927783
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "פארק עופר",
        "Address": "א.ס. לוי",
        "Latitude": 31.92395,
        "Longitude": 34.85723,
        "city": "Ramla"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.857228,
          31.92395
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "אברהם",
        "Address": "משה שרת 30",
        "Latitude": 32.0865,
        "Longitude": 34.81873,
        "city": "Ramat Gan"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.818725,
          32.086496
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "ביאליק",
        "Address": "ביאליק 99",
        "Latitude": 32.08681,
        "Longitude": 34.80677,
        "city": "Ramat Gan"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.80677423,
          32.08680737
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "בראשית",
        "Address": "דב פרידמן 19",
        "Latitude": 32.08096,
        "Longitude": 34.80323,
        "city": "Ramat Gan"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.803234,
          32.080961
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "האקליפטוס",
        "Address": "יהלום 1",
        "Latitude": 32.04349,
        "Longitude": 34.83145,
        "city": "Ramat Gan"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.831445,
          32.043491
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "הבילויים",
        "Address": "הבילויים 39",
        "Latitude": 32.06054,
        "Longitude": 34.82625,
        "city": "Ramat Gan"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.826254,
          32.06054
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "החרוזים",
        "Address": "חרוזים 12",
        "Latitude": 32.09108,
        "Longitude": 34.80382,
        "city": "Ramat Gan"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.803822,
          32.09108
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "המלך דוד",
        "Address": "שד' הילד 8",
        "Latitude": 32.08586,
        "Longitude": 34.81351,
        "city": "Ramat Gan"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.813509,
          32.085859
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "הפודים",
        "Address": "הפודים 21",
        "Latitude": 32.09204,
        "Longitude": 34.8186,
        "city": "Ramat Gan"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.818603,
          32.092044
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "הר הארנבות",
        "Address": "יבנה 9",
        "Latitude": 32.08156,
        "Longitude": 34.82399,
        "city": "Ramat Gan"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.823988,
          32.081564
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "הר הבנים",
        "Address": "מעלה הבנים",
        "Latitude": 32.07621,
        "Longitude": 34.82145,
        "city": "Ramat Gan"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.821446,
          32.076207
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "התותחן",
        "Address": "העמל 5",
        "Latitude": 32.09328,
        "Longitude": 34.81854,
        "city": "Ramat Gan"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.818543,
          32.093276
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "ואדי כופר",
        "Address": "עולי הגרדום פינת התפוצות",
        "Latitude": 32.06499,
        "Longitude": 34.83595,
        "city": "Ramat Gan"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.835945,
          32.064991
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "חורשת אדיס דה פיליפ",
        "Address": "המאה ואחד 28",
        "Latitude": 32.05607,
        "Longitude": 34.81899,
        "city": "Ramat Gan"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.818992,
          32.056069
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "חורשת האורנים",
        "Address": "יצחק רבין 8",
        "Latitude": 32.06049,
        "Longitude": 34.82102,
        "city": "Ramat Gan"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.821021,
          32.06049
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "יהודה",
        "Address": "לאן 16",
        "Latitude": 32.08178,
        "Longitude": 34.80845,
        "city": "Ramat Gan"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.808447,
          32.081777
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "עוזיאל",
        "Address": "בין נידוני קהיר ועוזיאל",
        "Latitude": 32.06753,
        "Longitude": 34.8213,
        "city": "Ramat Gan"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.821297,
          32.06753
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "עמירם",
        "Address": "הגת 8",
        "Latitude": 32.08481,
        "Longitude": 34.82061,
        "city": "Ramat Gan"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.820611,
          32.084807
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "פארק מרום נווה",
        "Address": "חיים לנדאו 6",
        "Latitude": 32.0713,
        "Longitude": 34.8288,
        "city": "Ramat Gan"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.828795,
          32.071296
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "צדוק",
        "Address": "אלרואי 41",
        "Latitude": 32.07165,
        "Longitude": 34.82175,
        "city": "Ramat Gan"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.821749,
          32.071652
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "קורין",
        "Address": "אבא הלל 66",
        "Latitude": 32.09006,
        "Longitude": 34.81054,
        "city": "Ramat Gan"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.810541,
          32.09006
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "קרית קריניצי",
        "Address": "ברוש 8",
        "Latitude": 32.06085,
        "Longitude": 34.84733,
        "city": "Ramat Gan"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.847332,
          32.060851
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "שאול",
        "Address": "מעלה הצופים 9",
        "Latitude": 32.08248,
        "Longitude": 34.81168,
        "city": "Ramat Gan"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.811684,
          32.082476
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "תהילה",
        "Address": "אצ\"ל9",
        "Latitude": 32.06498,
        "Longitude": 34.83108,
        "city": "Ramat Gan"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.831082,
          32.06498
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "תל אביב",
        "Address": "רוקח 100",
        "Latitude": 32.09535,
        "Longitude": 34.81172,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.811722,
          32.095354
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "דוד בן גוריון",
        "Address": "דוד בן גוריון 142",
        "Latitude": 32.14099,
        "Longitude": 34.83388,
        "city": "Ramat HaSharon"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.833882,
          32.140995
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "הגפן 34",
        "Address": "הגפן 34",
        "Latitude": 32.12969,
        "Longitude": 34.8458,
        "city": "Ramat HaSharon"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.845803,
          32.129688
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "הגפן 4",
        "Address": "הגפן 4",
        "Latitude": 32.13171,
        "Longitude": 34.8425,
        "city": "Ramat HaSharon"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.842496,
          32.131712
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "הטבק",
        "Address": "הטבק 13",
        "Latitude": 32.14959,
        "Longitude": 34.84199,
        "city": "Ramat HaSharon"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.841992,
          32.149594
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "המעפילים",
        "Address": "המעפילים 12",
        "Latitude": 32.15145,
        "Longitude": 34.83798,
        "city": "Ramat HaSharon"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.837976,
          32.151449
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "הנביאים",
        "Address": "הנביאים 43",
        "Latitude": 32.12946,
        "Longitude": 34.85586,
        "city": "Ramat HaSharon"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.855855,
          32.129458
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "העבודה",
        "Address": "העבודה 15",
        "Latitude": 32.13912,
        "Longitude": 34.83884,
        "city": "Ramat HaSharon"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.838839,
          32.139121
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "השילוח",
        "Address": "השילוח 12",
        "Latitude": 32.14616,
        "Longitude": 34.84712,
        "city": "Ramat HaSharon"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.847118,
          32.146159
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "חורשת מוריה",
        "Address": "מוריה 20",
        "Latitude": 32.14362,
        "Longitude": 34.83647,
        "city": "Ramat HaSharon"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.836472,
          32.14362
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "פארק הנצח",
        "Address": "הנצח 3",
        "Latitude": 32.13901,
        "Longitude": 34.84539,
        "city": "Ramat HaSharon"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.845388,
          32.139007
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "פארק נווה רעים",
        "Address": "יגאל אלון 7",
        "Latitude": 32.13,
        "Longitude": 34.86165,
        "city": "Ramat HaSharon"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.861647,
          32.129997
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "בית הלל",
        "Address": "בית הלל",
        "Latitude": 32.18144,
        "Longitude": 34.88009,
        "city": "Raanana"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.880088,
          32.181435
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "גנדל",
        "Address": "גולומב 1",
        "Latitude": 32.18245,
        "Longitude": 34.87543,
        "city": "Raanana"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.875428,
          32.182452
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "היער הקטן",
        "Address": "ארלוזורוב פינת פרדס משותף",
        "Latitude": 32.17302,
        "Longitude": 34.87703,
        "city": "Raanana"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.877032,
          32.173022
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "הנשיאים",
        "Address": "הנשיאים פינת וייצמן",
        "Latitude": 32.19217,
        "Longitude": 34.86337,
        "city": "Raanana"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.863367,
          32.192165
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "הסייפן",
        "Address": "הסייפן פינת וייצמן",
        "Latitude": 32.19197,
        "Longitude": 34.84851,
        "city": "Raanana"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.848511,
          32.191966
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "הפעמונים",
        "Address": "הפעמונים",
        "Latitude": 32.18166,
        "Longitude": 34.85686,
        "city": "Raanana"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.856856,
          32.181662
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "הפרחים",
        "Address": "הפרחים סמוך לביה\"סתל\"י",
        "Latitude": 32.1811,
        "Longitude": 34.85398,
        "city": "Raanana"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.853979,
          32.181102
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "יערה",
        "Address": "יערה 6",
        "Latitude": 32.18432,
        "Longitude": 34.88908,
        "city": "Raanana"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.889081,
          32.184324
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "קרית גנים",
        "Address": "הערבה 10",
        "Latitude": 32.18895,
        "Longitude": 34.85541,
        "city": "Raanana"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.855414,
          32.188953
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "החבל",
        "Address": "החבל",
        "Latitude": 32.00444,
        "Longitude": 34.94348,
        "city": "Shoham"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.943483,
          32.00444
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "העמק",
        "Address": "האודם 6",
        "Latitude": 31.99413,
        "Longitude": 34.94141,
        "city": "Shoham"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.941406,
          31.994133
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "סחלבים",
        "Address": "הדקל",
        "Latitude": 32.00473,
        "Longitude": 34.95122,
        "city": "Shoham"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.951222,
          32.004731
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "קדם",
        "Address": "קדם 39",
        "Latitude": 31.9962,
        "Longitude": 34.9505,
        "city": "Shoham"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.950504,
          31.996195
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "אדירים",
        "Address": "אדירים 24",
        "Latitude": 32.12266,
        "Longitude": 34.84094,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.84094,
          32.122659
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "אלכסנדר 19",
        "Address": "אלכסנדר פן 19",
        "Latitude": 32.12381,
        "Longitude": 34.81143,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.811428,
          32.123812
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "אלפרד ביר",
        "Address": "אליהו חכים 7",
        "Latitude": 32.12632,
        "Longitude": 34.80111,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.801112,
          32.126315
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "אשכנזי",
        "Address": "אשכנזי 33",
        "Latitude": 32.11119,
        "Longitude": 34.83078,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.830775,
          32.111194
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "בילטמור",
        "Address": "בילטמור 12",
        "Latitude": 32.0887,
        "Longitude": 34.78722,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.787222,
          32.088699
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "בית הבילויים",
        "Address": "מרדכי בנטוב 3",
        "Latitude": 32.04232,
        "Longitude": 34.76848,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.768478,
          32.042321
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "בית יד לבנים",
        "Address": "פנקס 63",
        "Latitude": 32.09199,
        "Longitude": 34.79318,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.793184,
          32.091992
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "בני אפרים / שטרית",
        "Address": "בני אפרים / בכור שלום שטרית",
        "Latitude": 32.1079,
        "Longitude": 34.81566,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.815656,
          32.107899
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "בני דן",
        "Address": "בני דן 37",
        "Latitude": 32.09644,
        "Longitude": 34.79206,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.792057,
          32.096435
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "ברנט",
        "Address": "ברנט 2",
        "Latitude": 32.06136,
        "Longitude": 34.76182,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.761821,
          32.061362
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "גימפל",
        "Address": "יחזקאל 3",
        "Latitude": 32.09308,
        "Longitude": 34.77704,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.77704,
          32.093075
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "גשר בר יהודה",
        "Address": "אבן גבירול 213",
        "Latitude": 32.09653,
        "Longitude": 34.78369,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.783693,
          32.096529
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "דגלאס",
        "Address": "תשרי 40",
        "Latitude": 32.04501,
        "Longitude": 34.78963,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.78963,
          32.045013
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "דובנוב",
        "Address": "דובנוב 24",
        "Latitude": 32.07801,
        "Longitude": 34.78404,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.784037,
          32.078008
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "דרויאנוב",
        "Address": "אליפלט 5",
        "Latitude": 32.05683,
        "Longitude": 34.76531,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.765308,
          32.056831
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "דרזנר",
        "Address": "יחיאל דב דרזנר 5",
        "Latitude": 32.12733,
        "Longitude": 34.80494,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.80494,
          32.127332
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "הגולן",
        "Address": "גולי אריתריאה 5",
        "Latitude": 32.1087,
        "Longitude": 34.83196,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.831959,
          32.108697
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "ההשכלה",
        "Address": "שדרות ההשכלה 18",
        "Latitude": 32.06714,
        "Longitude": 34.79658,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.796579,
          32.067137
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "הכובשים",
        "Address": "כרם התימנים 2",
        "Latitude": 32.06906,
        "Longitude": 34.7661,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.766103,
          32.06906
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "הכובשים 78",
        "Address": "הכובשים 78",
        "Latitude": 32.06659,
        "Longitude": 34.76512,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.76512,
          32.066589
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "המייסדים",
        "Address": "אורי צבי גרינברג 25",
        "Latitude": 32.12945,
        "Longitude": 34.79093,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.790933,
          32.129447
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "העיר",
        "Address": "הדסה 3",
        "Latitude": 32.08287,
        "Longitude": 34.77867,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.778673,
          32.082869
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "העצמאות",
        "Address": "הירקון 228",
        "Latitude": 32.09111,
        "Longitude": 34.77166,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.771657,
          32.091111
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "הר ציון",
        "Address": "שדרות הר ציון 107",
        "Latitude": 32.05059,
        "Longitude": 34.77402,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.774021,
          32.050588
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "השרון",
        "Address": "החשמל 8",
        "Latitude": 32.06121,
        "Longitude": 34.77525,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.775252,
          32.061212
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "התיבונים",
        "Address": "התיבונים 42",
        "Latitude": 32.05356,
        "Longitude": 34.77995,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.779948,
          32.053555
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "וייץ",
        "Address": "הרב גליקסברג / לאה גולדברג",
        "Latitude": 32.11838,
        "Longitude": 34.82265,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.822654,
          32.118384
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "וילנסקי",
        "Address": "משה וילנסקי 16",
        "Latitude": 32.12803,
        "Longitude": 34.83195,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.831951,
          32.128033
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "וינר",
        "Address": "מנדלשטם 11",
        "Latitude": 32.0909,
        "Longitude": 34.77659,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.776594,
          32.090904
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "חורשת אבוקה",
        "Address": "אבוקה 5",
        "Latitude": 32.12384,
        "Longitude": 34.82936,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.829363,
          32.123837
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "חורשת אברהם בויאר",
        "Address": "אברהם בויאר 5",
        "Latitude": 32.12437,
        "Longitude": 34.7955,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.7955,
          32.124373
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "חורשת אלברט קיוסו",
        "Address": "אלברט קיוסו 11",
        "Latitude": 32.04892,
        "Longitude": 34.75496,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.754964,
          32.048925
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "חורשת בית אל",
        "Address": "בית אל 30",
        "Latitude": 32.11732,
        "Longitude": 34.8415,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.841502,
          32.117321
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "חורשת בני יהודה",
        "Address": "תדהר 46",
        "Latitude": 32.04997,
        "Longitude": 34.78598,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.785978,
          32.049973
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "חורשת הורודצקי",
        "Address": "משה דיין 117",
        "Latitude": 32.06467,
        "Longitude": 34.79927,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.799272,
          32.064665
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "חורשת נהרדעא",
        "Address": "סוטין 22",
        "Latitude": 32.08207,
        "Longitude": 34.78609,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.786092,
          32.082068
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "חורשת עולי הגרדום",
        "Address": "עולי הגרדום 25",
        "Latitude": 32.11242,
        "Longitude": 34.83566,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.835661,
          32.112415
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "חורשת פרנקפורט",
        "Address": "קהילת ורשה 75",
        "Latitude": 32.10844,
        "Longitude": 34.8228,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.822802,
          32.10844
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "חורשת רבנו ירוחם",
        "Address": "רבנו ירוחם 7",
        "Latitude": 32.04881,
        "Longitude": 34.76055,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.760552,
          32.048807
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "חורשת רומנו",
        "Address": "רומנו 1",
        "Latitude": 32.12091,
        "Longitude": 34.81466,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.814658,
          32.120913
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "חורשת רפידים",
        "Address": "רפידים 22",
        "Latitude": 32.11242,
        "Longitude": 34.8116,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.811601,
          32.112417
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "חורשת שטיינמן",
        "Address": "אליעזר שטיינמן 11",
        "Latitude": 32.09824,
        "Longitude": 34.80077,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.800768,
          32.098238
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "חיים מבורך",
        "Address": "מגדל שרשן 14",
        "Latitude": 32.11758,
        "Longitude": 34.81284,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.812842,
          32.117583
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "חניון שוק גבעת עליה",
        "Address": "דוד וולפסון 48",
        "Latitude": 32.05758,
        "Longitude": 34.7741,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.774099,
          32.057575
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "טאגור",
        "Address": "טאגור 30",
        "Latitude": 32.11699,
        "Longitude": 34.79656,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.796556,
          32.116988
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "טבריה",
        "Address": "טבריה 1",
        "Latitude": 32.07605,
        "Longitude": 34.77047,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.770466,
          32.076055
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "יגאל אלון פינת ערבי נחל",
        "Address": "יגאל אלון 165",
        "Latitude": 32.07932,
        "Longitude": 34.79851,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.798512,
          32.079322
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "כוכב הצפון",
        "Address": "אבא קובנר 18",
        "Latitude": 32.10157,
        "Longitude": 34.78801,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.788007,
          32.101574
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "כוכב הצפון",
        "Address": "מאוריציו ויטלה 9",
        "Latitude": 32.10224,
        "Longitude": 34.79184,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.791842,
          32.102243
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "כיכר המדינה - עקיבא אריה",
        "Address": "ה' באייר / אריה עקיבא",
        "Latitude": 32.08734,
        "Longitude": 34.79074,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.790741,
          32.087336
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "לבנדה",
        "Address": "לבנדה / עין הקורא",
        "Latitude": 32.05722,
        "Longitude": 34.78297,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.782974,
          32.057221
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "לה גווארדיה",
        "Address": "לה גווארדיה 59",
        "Latitude": 32.0592,
        "Longitude": 34.79619,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.796185,
          32.059196
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "מאיר",
        "Address": "המלך ג'ורג' 35",
        "Latitude": 32.0732,
        "Longitude": 34.77329,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.77329,
          32.0732
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "מוריץ דניאל",
        "Address": "מוריץ דניאל 32",
        "Latitude": 32.11645,
        "Longitude": 34.79903,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.799027,
          32.116445
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "מייזל זלמן",
        "Address": "מייזל זלמן 1",
        "Latitude": 32.03155,
        "Longitude": 34.74808,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.74808,
          32.031547
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "מנחם ארבר 14",
        "Address": "מנחם ארבר 14",
        "Latitude": 32.04229,
        "Longitude": 34.76705,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.767046,
          32.042288
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "מעפילי אגוז",
        "Address": "מעפילי אגוז 73",
        "Latitude": 32.0544,
        "Longitude": 34.80881,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.808811,
          32.054396
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "מרדכי מאיר",
        "Address": "מרדכי מאיר 4",
        "Latitude": 32.12255,
        "Longitude": 34.81447,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.814472,
          32.122553
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "מרק שגאל",
        "Address": "מרק שגאל 1",
        "Latitude": 32.11839,
        "Longitude": 34.78719,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.787186,
          32.118392
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "משה דיין",
        "Address": "משה דיין 62",
        "Latitude": 32.0567,
        "Longitude": 34.80047,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.800465,
          32.056695
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "סעדיה שושני",
        "Address": "רמות נפתלי 13",
        "Latitude": 32.11547,
        "Longitude": 34.83618,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.836184,
          32.115472
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "פארק אופטושו",
        "Address": "רינגלבלום 20",
        "Latitude": 32.04119,
        "Longitude": 34.78101,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.781007,
          32.04119
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "פארק החורשות",
        "Address": "עופר כהן 16",
        "Latitude": 32.04648,
        "Longitude": 34.77267,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.772671,
          32.046483
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "פארק וולפסון",
        "Address": "השלום 120",
        "Latitude": 32.05903,
        "Longitude": 34.80581,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.805812,
          32.05903
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "פארק מודעי",
        "Address": "הפרסה 19",
        "Latitude": 32.12125,
        "Longitude": 34.83756,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.837561,
          32.121251
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "פארק מנחם בגין",
        "Address": "בירנית",
        "Latitude": 32.04126,
        "Longitude": 34.80418,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.804179,
          32.041258
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "פארק צמרת",
        "Address": "קריאל גרדוש",
        "Latitude": 32.08944,
        "Longitude": 34.79805,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.798046,
          32.089435
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "פארק ראול וולנברג",
        "Address": "הגולן 132",
        "Latitude": 32.11459,
        "Longitude": 34.83867,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.838671,
          32.114586
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "פוליטי",
        "Address": "הרב אשי 14",
        "Latitude": 32.12062,
        "Longitude": 34.79953,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.799532,
          32.12062
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "פייבל",
        "Address": "ליסין 25",
        "Latitude": 32.08424,
        "Longitude": 34.79371,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.793714,
          32.084239
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "פיקוס 28",
        "Address": "פיקוס 28",
        "Latitude": 32.03662,
        "Longitude": 34.7521,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.752103,
          32.036621
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "קהילת קייב",
        "Address": "קהילת קייב 1",
        "Latitude": 32.11408,
        "Longitude": 34.81857,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.818572,
          32.114075
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "קהילת ריגה",
        "Address": "קהילת ריגה / מבצע קדש",
        "Latitude": 32.11282,
        "Longitude": 34.82066,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.820662,
          32.112819
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "קוממיות",
        "Address": "קוממיות 26",
        "Latitude": 32.11924,
        "Longitude": 34.80542,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.805415,
          32.119244
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "קרית ספר",
        "Address": "יהודה הלוי 84",
        "Latitude": 32.06839,
        "Longitude": 34.78091,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.780911,
          32.068389
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "קרן קיימת - משמר הגבול",
        "Address": "משמר הגבול 3",
        "Latitude": 32.12188,
        "Longitude": 34.8037,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.803696,
          32.121882
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "ראש הכפר",
        "Address": "מנחם וטוביה מדמון 1",
        "Latitude": 32.05027,
        "Longitude": 34.80422,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.804216,
          32.050266
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "ראש ציפור",
        "Address": "קוסובסקי - מפגש הנחלים הירקון ואיילון",
        "Latitude": 32.09948,
        "Longitude": 34.8026,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.802597,
          32.099483
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "רדינג",
        "Address": "רדינג 39",
        "Latitude": 32.1085,
        "Longitude": 34.79418,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.794176,
          32.108497
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "ריקליס",
        "Address": "פליטי הספר 19",
        "Latitude": 32.06907,
        "Longitude": 34.80145,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.801455,
          32.069065
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "רפידים-צפון",
        "Address": "תל ברוך 13",
        "Latitude": 32.11843,
        "Longitude": 34.81202,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.812015,
          32.118432
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "שפע טל",
        "Address": "שפע טל 2",
        "Latitude": 32.07219,
        "Longitude": 34.79054,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.790539,
          32.072192
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "תוצרת הארץ",
        "Address": "תוצרת הארץ 11",
        "Latitude": 32.07316,
        "Longitude": 34.79792,
        "city": "Tel Aviv"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.797922,
          32.073155
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "חורשת האירועים",
        "Address": "המטעים",
        "Latitude": 32.24916,
        "Longitude": 34.91891,
        "city": "Tel Mond"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.9189067,
          32.24915885
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "פארק הדקלים",
        "Address": "הדקל",
        "Latitude": 32.25978,
        "Longitude": 34.92265,
        "city": "Tel Mond"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.92264755,
          32.25978383
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "Name": "פארק ההדרים",
        "Address": "הנוטע",
        "Latitude": 32.25224,
        "Longitude": 34.91071,
        "city": "Tel Mond"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.91070656,
          32.25224253
        ]
      }
    }
  ]
}

module.exports = json_Doggoexcel_1;