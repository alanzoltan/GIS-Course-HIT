var wms_layers = [];


        var lyr_OpenStreetMap_0 = new ol.layer.Tile({
            'title': 'OpenStreetMap',
            'opacity': 1.000000,
            
            
            source: new ol.source.XYZ({
            attributions: ' ',
                url: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png'
            })
        });

var format_Doggoexcel_1 = new ol.format.GeoJSON();
var features_Doggoexcel_1 = format_Doggoexcel_1.readFeatures(json_Doggoexcel_1, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_Doggoexcel_1 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_Doggoexcel_1.addFeatures(features_Doggoexcel_1);
var lyr_Doggoexcel_1 = new ol.layer.Vector({
    declutter: false,
    source: jsonSource_Doggoexcel_1, 
    style: style_Doggoexcel_1,
    popuplayertitle: "Doggo - Park",
    interactive: true,
    title: '<img src="styles/legend/Doggoexcel_1.png" /> Doggo - excel'
});

lyr_OpenStreetMap_0.setVisible(true);
lyr_Doggoexcel_1.setVisible(true);
var layersList = [lyr_OpenStreetMap_0, lyr_Doggoexcel_1];
lyr_Doggoexcel_1.set('fieldAliases', {'Name': 'Name', 'Address': 'Address', 'Latitude': 'Latitude', 'Longitude': 'Longitude', 'city': 'city'});
lyr_Doggoexcel_1.set('fieldImages', {'Name': 'TextEdit', 'Address': 'TextEdit', 'Latitude': 'TextEdit', 'Longitude': 'TextEdit', 'city': 'TextEdit'});
lyr_Doggoexcel_1.set('fieldLabels', {'Name': 'no label', 'Address': 'no label', 'Latitude': 'no label', 'Longitude': 'no label', 'city': 'no label'});
lyr_Doggoexcel_1.on('precompose', function(evt) {
    evt.context.globalCompositeOperation = 'normal';
});

map.on('singleclick', function(evt) {
    var coordinate = evt.coordinate;
    var feature = map.forEachFeatureAtPixel(evt.pixel, function(feature) {
        return feature;
    });

    if (feature) {
        var properties = feature.getProperties();
        curParkName = properties.Name;
        curParkCoords = [properties.Longitude, properties.Latitude];

        let favorites = JSON.parse(localStorage.getItem('favoriteParks')) || [];
        const isFavorite = favorites.some(park => park.name === properties.Name && park.address === properties.Address);
        const favButtonId = 'favorite-button-' + properties.Name.replace(/\s/g, ''); // Create a unique ID

        let buttonContent = isFavorite
            ? '<img src="styles/fav_p.png" alt="Favorite" style="width: 20px; height: 20px; vertical-align: middle;">'
            : '<img src="styles/fav_np.png" alt="Not Favorite" style="width: 20px; height: 20px; vertical-align: middle;">';

        var popupContent = '<div>' +
            '<p><strong>Name:</strong> <span class="feature-name">' + properties.Name + '</span></p>' +
            '<p><strong>Address:</strong> <span class="feature-address">' + properties.Address + '</span></p>' +
            '<div class="button-container">' +
            '<button id="goto-button" onclick="goToLocation()"><img src="styles/g-svg.svg" alt="Go To" style="width: 20px; height: 20px; vertical-align: middle;"></button>' +
            `<button id="${favButtonId}" onclick="toggleFavoriteStatus(this, '${properties.Name}', '${properties.Address}')">${buttonContent}</button>` +
            '</div>' +
            '</div>';

        content.innerHTML = popupContent;
        overlay.setPosition(coordinate);
    } else {
        overlay.setPosition(undefined);
        closer.blur();
    }
});

function goToLocation() {
    if (curParkCoords) {
        var googleMapsUrl = 'https://www.google.com/maps/dir/?api=1&destination=' + curParkCoords[1] + ',' + curParkCoords[0];
        window.open(googleMapsUrl, '_blank');
    } else {
        alert('No location available.');
    }
}

function toggleFavoriteStatus(button, name, address) {
    let favorites = JSON.parse(localStorage.getItem('favoriteParks')) || [];
    const isFavorite = favorites.some(park => park.name === name && park.address === address);
    const favButtonId = 'favorite-button-' + name.replace(/\s/g, '');

    if (isFavorite) {
        // Remove from favorites
        favorites = favorites.filter(park => !(park.name === name && park.address === address));
        button.innerHTML = '<img src="styles/fav_np.png" alt="Not Favorite" style="width: 20px; height: 20px; vertical-align: middle;">';
        alert('Park removed from favorites!');
    } else {
        // Add to favorites
        favorites.push({ name: name, address: address });
        button.innerHTML = '<img src="styles/fav_p.png" alt="Favorite" style="width: 20px; height: 20px; vertical-align: middle;">';
        alert('Park added to favorites!');
    }

    localStorage.setItem('favoriteParks', JSON.stringify(favorites));
}