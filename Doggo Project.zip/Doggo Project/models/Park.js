// models/Park.js
const mongoose = require("mongoose");

// If using a separate DB for parks:
const dogParksConnection = mongoose.createConnection("mongodb://localhost:27017/dogParksDB", {
  useNewUrlParser: true,
  useUnifiedTopology: true
});

dogParksConnection.on("connected", () => {
  console.log("Connected to dogParksDB for parks");
});

const parkSchema = new mongoose.Schema({
  name: String,
  address: String,
  city: String,
  latitude: Number,
  longitude: Number,
  location: {
    type: {
      type: String,
      enum: ["Point"],
      default: "Point"
    },
    coordinates: {
      type: [Number],
      index: "2dsphere"
    }
  }
});

// Compile the model using the dogParksConnection
const Park = dogParksConnection.model("Park", parkSchema);

module.exports = Park;
