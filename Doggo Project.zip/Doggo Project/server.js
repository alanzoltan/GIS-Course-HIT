const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const bodyParser = require("body-parser");
const bcrypt = require("bcrypt");

const app = express();
app.use(cors());
app.use(bodyParser.json({ limit: '10mb' }));
app.use(bodyParser.urlencoded({ limit: '10mb', extended: true }));

// ---------------------------------------------------------------------------
// 1) CONNECT TO USERS DATABASE (usersDB) FOR USER-RELATED OPERATIONS
// ---------------------------------------------------------------------------
mongoose.connect("mongodb://localhost:27017/usersDB", {
    useNewUrlParser: true,
    useUnifiedTopology: true
})
.then(() => console.log("Connected to usersDB"))
.catch(err => console.error("Error connecting to usersDB:", err));

// Define User Schema for usersDB
const userSchema = new mongoose.Schema({
    username: String,
    email: String,
    password: String,
    profilePicture: String,
    favoriteParks: [
      {
        name: String,
        address: String,
        latitude: Number,
        longitude: Number,
        city: String
      }
    ],
    dogs: [
      {
        name: String,
        picture: String
      }
    ]
  });
  
const User = mongoose.model("User", userSchema);

// ---------------------------------------------------------------------------
// 2) IMPORT THE PARK MODEL FROM A SEPARATE FILE (models/Park.js)
// ---------------------------------------------------------------------------
const Park = require("./models/Park"); 
// This Park model is either using the same DB or a separate "dogParksDB" connection
// depending on how you set up models/Park.js

// ---------------------------------------------------------------------------
// 3) USER ROUTES (Signup, Login, Update Profile) - Using usersDB
// ---------------------------------------------------------------------------

// Root Route
app.get("/", (req, res) => {
    res.send("Server is running!");
});

// Signup Route
app.post("/signup", async (req, res) => {
    try {
        const { username, email, password } = req.body;

        // Check if user exists in usersDB
        const existingUser = await User.findOne({ email });
        if (existingUser) {
            return res.status(400).json({ success: false, message: "Email already registered" });
        }

        // Hash the password before saving
        const hashedPassword = await bcrypt.hash(password, 10);

        // Create new user document
        const newUser = new User({ username, email, password: hashedPassword });
        await newUser.save();

        res.json({ success: true, message: "User registered successfully" });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: "Server error" });
    }
});

// Login Route
app.post("/login", async (req, res) => {
    try {
        const { username, password } = req.body;

        // Find user by username in usersDB
        const user = await User.findOne({ username });
        if (!user) {
            return res.status(400).json({ success: false, message: "User not found" });
        }

        // Compare hashed password
        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(400).json({ success: false, message: "Invalid credentials" });
        }

        // Return the user's email and profile picture
        res.json({
            success: true,
            message: "Login successful!",
            email: user.email,
            profilePicture: user.profilePicture
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: "Server error" });
    }
});

// Update Profile Route
app.post("/updateProfile", async (req, res) => {
    try {
        const { username, profilePicture, favoriteParks, dogs } = req.body;

        console.log("Received profile update request for:", username);
        console.log("Profile Picture:", profilePicture ? profilePicture.substring(0, 50) + "..." : null);
        console.log("Favorite Parks:", favoriteParks);
        console.log("Dogs:", dogs);

        // Find user by username and update in usersDB
        const user = await User.findOneAndUpdate(
            { username },
            { profilePicture, favoriteParks, dogs },
            { new: true }
        );

        if (!user) {
            return res.status(400).json({ success: false, message: "User not found" });
        }

        console.log("Profile updated successfully:", user);
        res.json({ success: true, message: "Profile updated successfully", user });
    } catch (error) {
        console.error("Error updating profile:", error);
        res.status(500).json({ success: false, message: "Server error" });
    }
});

// Fetch User Profile Route
app.get("/profile", async (req, res) => {
    try {
        const { username } = req.query;

        // Find user by username in usersDB
        const user = await User.findOne({ username });
        if (!user) {
            return res.status(400).json({ success: false, message: "User not found" });
        }

        // Return the user's profile data
        res.json({
            success: true,
            user: {
                username: user.username,
                email: user.email,
                profilePicture: user.profilePicture,
                favoriteParks: user.favoriteParks,
                dogs: user.dogs
            }
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: "Server error" });
    }
});

// ---------------------------------------------------------------------------
// 4) PARKS ROUTE (Fetch Dog Parks) - Using Park model from models/Park.js
// ---------------------------------------------------------------------------
app.get("/api/parks", async (req, res) => {
    try {
        // Query parks from the Park model (whether in dogParksDB or usersDB, 
        // depending on your Park.js config)
        const parks = await Park.find({});
        
        // Convert the parks into GeoJSON features
        const features = parks.map(park => ({
            type: "Feature",
            properties: {
                Name: park.name,
                Address: park.address,
                Latitude: park.latitude,
                Longitude: park.longitude,
                city: park.city
            },
            geometry: {
                type: "Point",
                coordinates: [park.longitude, park.latitude]
            }
        }));

        const geojson = {
            type: "FeatureCollection",
            features: features
        };

        res.json(geojson);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: "Server error" });
    }
});



// ---------------------------------------------------------------------------
// 5) ERROR HANDLING AND START THE SERVER
// ---------------------------------------------------------------------------
app.use((err, req, res, next) => {
    if (err.type === "entity.too.large") {
        res.status(413).json({ success: false, message: "Payload too large" });
    } else {
        next(err);
    }
});

app.listen(8080, () => {
    console.log("Server running on http://localhost:8080");
});
